﻿namespace Properties1
{
    internal class Program
    {
        static void Main1()
        {
            int i; //unassigned
            i = 0;
            //Console.WriteLine(i);

            Class1 o = new Class1();
            //o.i = 10000;
            //Console.WriteLine(o.i);
            o.Seti(1000);
            Console.WriteLine(o.Geti());
            o.j = ++o.j + o.j++ - --o.j - o.j--;
            //o.Seti(++o.Geti());

        }
    }
    //DO NOT EVER USE GETTERS AND SETTERS!!!!!
    //INSTEAD USE PROPERTIES
    public class Class1
    {
        public int j;
        private int i;
        public void Seti(int VALUE)
        {
            if(VALUE <100)
                i = VALUE;
            else
                //throw new Exception......
                Console.WriteLine("invalid i");
        }
        public int Geti()
        {
            return i;   
        }
    }
}

namespace Properties2
{
    internal class Program
    {
        static void Main()
        {
            Class1 o = new Class1();
            o.P1 = 10000; //set
            Console.WriteLine(o.P1); //get

            //o.P3= "aaaaa"; //error, read only
            Console.WriteLine(o.P3);

            o.P5 = "aaaaa";
            Console.WriteLine(o.P5);

        }
    }
    public class Class1a
    {
        public int j;
        private int i;
        public void Seti(int VALUE)
        {
            if (VALUE < 100)
                i = VALUE;
            else
                //throw new Exception......
                Console.WriteLine("invalid i");
        }
        public int Geti()
        {
            return i;
        }
    }
    public class Class1
    {
        private int p1;
        public int P1
        {
            set 
            { 
                if(value < 100)
                    p1 = value;
                else
                    Console.WriteLine("invalid p1");
            }
            get 
            { 
                return p1;  
            }
        }
        private string p2;
        public string P2
        {
            set 
            { 
                p2 = value;
            }
            get 
            {
                return p2;
            }
        }
        private string p3="read only property";
        public string P3
        {
            get
            {
                return p3;
            }
        }
        public string P4; //field / class level variable

        //automatic property
        //no validations
        //compiler will generate variable
        //compiler will generate the set and the get
        public string P5 { set; get; }
    }
}